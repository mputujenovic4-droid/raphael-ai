# Raphaël AI

Un chat IA avec son propre serveur (Node.js + Express). La clé API reste côté serveur.

## Lancer
1. Installe Node.js 18+.
2. `npm install`
3. `export ANTHROPIC_API_KEY=ta_cle` (clé sur console.anthropic.com)
4. `npm start` puis ouvre http://localhost:3000

## Prochaines étapes possibles
Comptes utilisateurs, historique en base de données, mise en ligne (Render, Railway, VPS), application mobile.
