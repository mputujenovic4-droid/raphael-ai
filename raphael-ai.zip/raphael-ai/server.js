import express from "express";
import Anthropic from "@anthropic-ai/sdk";
import { fileURLToPath } from "url";
import path from "path";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const client = new Anthropic(); // lit ANTHROPIC_API_KEY dans l'environnement
const MODEL = process.env.MODEL || "claude-sonnet-5-5";
const MODELS = [
  { id: "claude-sonnet-5-5", label: "Équilibré (Sonnet)" },
  { id: "claude-haiku-5-5", label: "Rapide (Haiku)" },
  { id: "claude-opus-5-5", label: "Puissant (Opus)" },
];
const SYSTEM = "Tu es Raphaël AI, un assistant utile, clair et concis. Réponds dans la langue de l'utilisateur.";

app.use(express.json({ limit: "200kb" }));
app.use(express.static(path.join(__dirname, "public")));

// Limite simple : 20 requêtes / minute / IP
const hits = new Map();
app.use("/api", (req, res, next) => {
  const now = Date.now();
  const recent = (hits.get(req.ip) || []).filter((t) => now - t < 60_000);
  if (recent.length >= 20) return res.status(429).json({ error: "Trop de requêtes, réessaie dans une minute." });
  recent.push(now);
  hits.set(req.ip, recent);
  next();
});

app.get("/api/models", (req, res) => res.json({ models: MODELS, default: MODEL }));

app.post("/api/chat", async (req, res) => {
  const { messages, model } = req.body || {};
  const chosen = MODELS.some((m) => m.id === model) ? model : MODEL;
  const valid =
    Array.isArray(messages) && messages.length > 0 &&
    messages.every((m) => ["user", "assistant"].includes(m.role) && typeof m.content === "string" && m.content.length < 20000);
  if (!valid) return res.status(400).json({ error: "Messages invalides." });

  res.setHeader("Content-Type", "text/plain; charset=utf-8");
  res.setHeader("Cache-Control", "no-cache");

  try {
    const stream = client.messages.stream({
      model: chosen,
      max_tokens: 1500,
      system: SYSTEM,
      messages: messages.slice(-30),
    });
    stream.on("text", (t) => res.write(t));
    await stream.finalMessage();
    res.end();
  } catch (err) {
    console.error(err);
    if (!res.headersSent) res.status(500).json({ error: "Erreur du serveur IA." });
    else res.end("\n\n[Erreur : la réponse a été interrompue.]");
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Raphaël AI tourne sur http://localhost:${port}`));
